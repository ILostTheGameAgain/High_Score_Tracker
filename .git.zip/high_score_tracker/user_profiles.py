# Jackson, User Profile Interaction
import pygame
from base_pygame import *

def user_profile_management(): # Manage the user profiles
    while True:
        pass