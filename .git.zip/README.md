# I lost the game


**Project Link**

https://ucas-edu.instructure.com/courses/3902/pages/high-score-tracker-project-description?module_item_id=169045


Jacksons Discord: 3334gfiop


